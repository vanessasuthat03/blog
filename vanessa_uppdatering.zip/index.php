

    <?php

require_once 'db.php';    
require_once 'header.php';
require_once 'view.php';
require_once 'footer.php';
    ?>

