<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Comic+Neue&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">

    <title>FEND19 Blogg</title>
  </head>
  <body id="index">

    <div class="container">
      <header class="index-header">
        <h1 class="index-rubrik">Birk och Vanessa reseblogg</h1>
      </header>

      <div class="row">
        <div class=" post col-md-8">

   




    