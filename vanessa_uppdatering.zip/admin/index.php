<?php

require_once '../db.php';    
require_once 'header-adm.php';
require_once 'read-blog.php';
require_once '../footer.php';
    ?>